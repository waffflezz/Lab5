package masks

case class Geolocation(`type`: String,
                       coordinates: List[Double])
